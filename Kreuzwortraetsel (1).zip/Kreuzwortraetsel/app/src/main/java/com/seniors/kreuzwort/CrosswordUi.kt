package com.seniors.kreuzwort

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

private val NightBlue = Color(0xFF121826)
private val PanelBlue = Color(0xFF1B2438)
private val InkDark = Color(0xFF0B1220)
private val WordBlue = Color(0xFF7CC0FF)
private val CellBlue = Color(0xFF1E6BFF)
private val SansBold = FontFamily.SansSerif

// ---------------------------------------------------------------- Spielzustand

class GameState(val puzzle: Puzzle) {
    val rows = puzzle.rows
    val cols = puzzle.cols
    val input = mutableStateListOf<Char>().apply { repeat(rows * cols) { add(' ') } }
    val locked = mutableStateListOf<Boolean>().apply { repeat(rows * cols) { add(false) } }
    val wordCells: List<List<Int>> = puzzle.words.map { it.cellIndices(cols) }
    var selectedWord by mutableIntStateOf(0)
    var selectedCell by mutableIntStateOf(-1)
    var wrongCells by mutableStateOf(setOf<Int>())
    var shakeTick by mutableIntStateOf(0)
    var message by mutableStateOf("")
    var solved by mutableStateOf(false)

    init { selectWord(0) }

    fun sol(i: Int): Char = puzzle.solution[i / cols][i % cols]

    fun selectWord(w: Int) {
        selectedWord = w
        val cells = wordCells[w]
        selectedCell = cells.firstOrNull { input[it] == ' ' } ?: cells.first()
    }

    fun tapCell(i: Int) {
        val words = wordCells.indices.filter { i in wordCells[it] }
        if (words.isEmpty()) return
        val pos = words.indexOf(selectedWord)
        selectedWord = when {
            pos >= 0 && selectedCell == i -> words[(pos + 1) % words.size]
            pos >= 0 -> selectedWord
            else -> words[0]
        }
        selectedCell = i
    }

    private fun move(d: Int) {
        val cells = wordCells[selectedWord]
        val n = cells.indexOf(selectedCell) + d
        if (n in cells.indices) selectedCell = cells[n]
    }

    fun type(ch: Char) {
        if (solved || selectedCell < 0) return
        message = ""
        if (!locked[selectedCell]) input[selectedCell] = ch
        move(1)
        checkSolved()
    }

    fun back() {
        if (solved || selectedCell < 0) return
        message = ""
        if (!locked[selectedCell] && input[selectedCell] != ' ') {
            input[selectedCell] = ' '
        } else {
            move(-1)
            if (!locked[selectedCell]) input[selectedCell] = ' '
        }
    }

    private fun checkSolved() {
        solved = input.indices.all { input[it] == sol(it) }
    }

    fun check() {
        if (solved) return
        val wrong = input.indices.filter { input[it] != ' ' && input[it] != sol(it) }.toSet()
        if (wrong.isNotEmpty()) {
            wrongCells = wrong
            shakeTick++
            message = "Einige Buchstaben stimmen noch nicht."
        } else if (input.indices.any { input[it] != sol(it) }) {
            message = "Alles bisher richtig – weiter so!"
        }
        checkSolved()
    }

    fun hint() {
        if (solved) return
        val open = { i: Int -> !locked[i] && input[i] != sol(i) }
        val target = wordCells[selectedWord].firstOrNull(open)
            ?: input.indices.filter { sol(it) != ' ' }.firstOrNull(open)
            ?: return
        input[target] = sol(target)
        locked[target] = true
        wrongCells = wrongCells - target
        message = "Ein Buchstabe wurde verraten."
        checkSolved()
    }
}

// ---------------------------------------------------------------- Hauptbildschirm

@Composable
fun CrosswordApp() {
    var state by remember { mutableStateOf(GameState(CrosswordGenerator.generate())) }
    val s = state
    Box(Modifier.fillMaxSize().background(NightBlue)) {
        Row(Modifier.fillMaxSize().padding(24.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            Column(Modifier.weight(1.2f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Banner(s)
                Grid(s, Modifier.weight(1f).fillMaxWidth())
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                ClueList(s, Modifier.weight(1f).fillMaxWidth())
                Text(
                    s.message.ifEmpty { " " },
                    color = Color(0xFFFFB74D), fontSize = 24.sp,
                    fontWeight = FontWeight.Bold, fontFamily = SansBold
                )
                Keyboard(s, Modifier.weight(1.15f).fillMaxWidth())
                Row(Modifier.weight(0.3f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionButton("Überprüfen", Icons.Filled.CheckCircle, Color(0xFF1FAF5B), Modifier.weight(1f).fillMaxHeight()) { s.check() }
                    ActionButton("Tipp geben", Icons.Filled.Lightbulb, Color(0xFFFF9800), Modifier.weight(1f).fillMaxHeight()) { s.hint() }
                    ActionButton("Neues Rätsel", Icons.Filled.Refresh, Color(0xFF2979FF), Modifier.weight(1f).fillMaxHeight()) {
                        state = GameState(CrosswordGenerator.generate())
                    }
                }
            }
        }
        if (s.solved) {
            Celebration { state = GameState(CrosswordGenerator.generate()) }
        }
    }
}

@Composable
private fun Banner(s: GameState) {
    val w = s.puzzle.words[s.selectedWord]
    val dirText = if (w.dir == Dir.ACROSS) "waagerecht" else "senkrecht"
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(PanelBlue).padding(horizontal = 24.dp, vertical = 14.dp)
    ) {
        Text(
            "${w.number} $dirText  ·  ${w.entry.category}  ·  ${w.length} Buchstaben",
            color = Color(0xFF9DB4D6), fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = SansBold
        )
        Text(
            w.entry.clue,
            color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold,
            fontFamily = SansBold, lineHeight = 42.sp
        )
    }
}

// ---------------------------------------------------------------- Gitter

@Composable
private fun Grid(s: GameState, modifier: Modifier) {
    val shake = remember { Animatable(0f) }
    LaunchedEffect(s.shakeTick) {
        if (s.shakeTick > 0) {
            repeat(5) {
                shake.animateTo(14f, tween(45))
                shake.animateTo(-14f, tween(45))
            }
            shake.animateTo(0f, tween(45))
            delay(400)
            s.wrongCells = emptySet()
        }
    }
    BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        val cell = minOf(maxWidth / s.cols, maxHeight / s.rows)
        Column {
            for (r in 0 until s.rows) {
                Row {
                    for (c in 0 until s.cols) {
                        GridCell(s, r, c, cell, shake)
                    }
                }
            }
        }
    }
}

@Composable
private fun GridCell(s: GameState, r: Int, c: Int, size: Dp, shake: Animatable<Float, AnimationVector1D>) {
    val i = r * s.cols + c
    if (s.puzzle.solution[r][c] == ' ') {
        Spacer(Modifier.size(size))
        return
    }
    val inWord = i in s.wordCells[s.selectedWord]
    val selected = i == s.selectedCell
    val bg = when {
        selected -> CellBlue
        inWord -> WordBlue
        i in s.wrongCells -> Color(0xFFFFCDD2)
        s.locked[i] -> Color(0xFFFFE0B2)
        else -> Color.White
    }
    val fg = if (selected) Color.White else InkDark
    val number = s.puzzle.words.firstOrNull { it.row == r && it.col == c }?.number
    val shape = RoundedCornerShape(size * 0.12f)
    Box(
        Modifier
            .size(size)
            .offset { IntOffset(if (i in s.wrongCells) shake.value.dp.roundToPx() else 0, 0) }
            .padding(size * 0.04f)
            .shadow(8.dp, shape)
            .clip(shape)
            .background(bg)
            .clickable { s.tapCell(i) },
        contentAlignment = Alignment.Center
    ) {
        if (number != null) {
            Text(
                number.toString(),
                Modifier.align(Alignment.TopStart).padding(start = size * 0.07f, top = size * 0.02f),
                color = if (selected) Color.White else Color(0xFF334155),
                fontSize = (size.value * 0.22f).sp, fontWeight = FontWeight.Bold, fontFamily = SansBold
            )
        }
        Text(
            s.input[i].toString(),
            color = fg, fontSize = (size.value * 0.58f).sp,
            fontWeight = FontWeight.Black, fontFamily = SansBold
        )
    }
}

// ---------------------------------------------------------------- Fragenliste

@Composable
private fun ClueList(s: GameState, modifier: Modifier) {
    val across = s.puzzle.words.indices.filter { s.puzzle.words[it].dir == Dir.ACROSS }
    val down = s.puzzle.words.indices.filter { s.puzzle.words[it].dir == Dir.DOWN }
    LazyColumn(
        modifier.clip(RoundedCornerShape(20.dp)).background(PanelBlue),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        item { ClueHeader("Waagerecht  →") }
        items(across) { ClueRow(s, it) }
        item { ClueHeader("Senkrecht  ↓") }
        items(down) { ClueRow(s, it) }
    }
}

@Composable
private fun ClueHeader(text: String) {
    Text(text, color = Color(0xFF7CC0FF), fontSize = 26.sp, fontWeight = FontWeight.Black,
        fontFamily = SansBold, modifier = Modifier.padding(top = 6.dp, start = 6.dp))
}

@Composable
private fun ClueRow(s: GameState, idx: Int) {
    val w = s.puzzle.words[idx]
    val selected = idx == s.selectedWord
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
            .background(if (selected) CellBlue else Color.Transparent)
            .clickable { s.selectWord(idx) }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("${w.number}", Modifier.width(44.dp), color = Color(0xFFFFD54F), fontSize = 26.sp,
            fontWeight = FontWeight.Black, fontFamily = SansBold)
        Text(w.entry.clue, color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold, fontFamily = SansBold)
    }
}

// ---------------------------------------------------------------- Tastatur

private val KEY_ROWS = listOf("QWERTZUIOPÜ", "ASDFGHJKLÖÄ", "YXCVBNM")

@Composable
private fun Keyboard(s: GameState, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        KEY_ROWS.forEachIndexed { idx, row ->
            Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { ch ->
                    Key(ch.toString(), null, Color(0xFFF1F5F9), InkDark, Modifier.weight(1f).fillMaxHeight()) { s.type(ch) }
                }
                if (idx == 2) {
                    Key("", Icons.AutoMirrored.Filled.Backspace, Color(0xFFE57373), Color.White,
                        Modifier.weight(4f).fillMaxHeight()) { s.back() }
                }
            }
        }
    }
}

@Composable
private fun Key(
    label: String, icon: ImageVector?, base: Color, fg: Color,
    modifier: Modifier, onClick: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val color by animateColorAsState(if (pressed) Color(0xFF00E5FF) else base, tween(80), label = "key")
    val shape = RoundedCornerShape(16.dp)
    BoxWithConstraints(
        modifier.shadow(6.dp, shape).clip(shape).background(color)
            .clickable(interactionSource = src, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        val fs = (maxHeight.value * 0.5f).sp
        if (icon != null) {
            Icon(icon, "Löschen", tint = if (pressed) InkDark else fg, modifier = Modifier.size(maxHeight * 0.6f))
        } else {
            Text(label, color = InkDark, fontSize = fs, fontWeight = FontWeight.Black, fontFamily = SansBold)
        }
    }
}

// ---------------------------------------------------------------- Steuerungs-Buttons

@Composable
private fun ActionButton(text: String, icon: ImageVector, base: Color, modifier: Modifier, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val color by animateColorAsState(if (pressed) lerp(base, Color.White, 0.4f) else base, tween(80), label = "btn")
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier.shadow(8.dp, shape).clip(shape).background(color)
            .clickable(interactionSource = src, indication = null) { onClick() }
            .padding(horizontal = 10.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(40.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black,
            fontFamily = SansBold, textAlign = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- Gratulation + Konfetti

private class Particle(
    val x: Float, val y0: Float, val speed: Float, val size: Float,
    val rot: Float, val spin: Float, val color: Color
)

@Composable
private fun Celebration(onNew: () -> Unit) {
    val colors = listOf(
        Color(0xFFFFD54F), Color(0xFFFF5252), Color(0xFF69F0AE),
        Color(0xFF40C4FF), Color(0xFFE040FB), Color(0xFFFFFFFF), Color(0xFFFF9800)
    )
    val parts = remember {
        List(180) {
            Particle(
                Random.nextFloat(), Random.nextFloat() * 1.2f, 0.12f + Random.nextFloat() * 0.3f,
                8f + Random.nextFloat() * 14f, Random.nextFloat() * 360f,
                (Random.nextFloat() - 0.5f) * 420f, colors.random()
            )
        }
    }
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { t = (it - start) / 1_000_000_000f }
        }
    }
    Box(
        Modifier.fillMaxSize().background(Color(0xEE121826))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            parts.forEach { p ->
                val y = ((p.y0 + p.speed * t) % 1.2f - 0.1f) * size.height
                val x = (p.x + 0.025f * sin(t * 2f + p.rot)) * size.width
                val s = p.size * density
                rotate(p.rot + p.spin * t, Offset(x, y)) {
                    drawRect(p.color, Offset(x - s / 2, y - s / 3), Size(s, s * 0.66f))
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Text("Wunderbar!", color = Color(0xFFFFD54F), fontSize = 130.sp,
                fontWeight = FontWeight.Black, fontFamily = SansBold)
            Text("Das Rätsel ist gelöst!", color = Color.White, fontSize = 54.sp,
                fontWeight = FontWeight.Bold, fontFamily = SansBold)
            Spacer(Modifier.height(20.dp))
            ActionButton("Neues Rätsel", Icons.Filled.Refresh, Color(0xFF2979FF), Modifier.height(100.dp).width(400.dp)) { onNew() }
        }
    }
}
