package com.seniors.kreuzwort

enum class Dir { ACROSS, DOWN }

data class Entry(val answer: String, val clue: String, val category: String)

data class PlacedWord(
    val number: Int,
    val entry: Entry,
    val row: Int,
    val col: Int,
    val dir: Dir
) {
    val length get() = entry.answer.length
    fun cellIndices(cols: Int): List<Int> = (0 until length).map {
        if (dir == Dir.ACROSS) row * cols + col + it else (row + it) * cols + col
    }
}

class Puzzle(
    val rows: Int,
    val cols: Int,
    val solution: Array<CharArray>,
    val words: List<PlacedWord>
)

object CrosswordGenerator {

    private const val SIZE = 19
    private const val TARGET_WORDS = 13
    private const val ATTEMPTS = 80

    const val MUSIK = "Alte Schlager & Musik"
    const val NATUR = "Natur & Garten"
    const val KUECHE = "Küche & Rezepte"
    const val GEO = "Geografie & Städte"

    private fun e(cat: String, answer: String, clue: String) = Entry(answer, clue, cat)

    val POOL: List<Entry> = listOf(
        e(MUSIK, "EDELWEISS", "Lied aus 'The Sound of Music' über eine Bergblume"),
        e(MUSIK, "HEINO", "Sänger mit dunkler Brille und blondem Haar"),
        e(MUSIK, "AKKORDEON", "Ziehharmonika, Instrument der Volksmusik"),
        e(MUSIK, "GITARRE", "Saiteninstrument mit sechs Saiten"),
        e(MUSIK, "WALZER", "Tanz im Dreivierteltakt"),
        e(MUSIK, "POLKA", "Böhmischer Tanz im Zweivierteltakt"),
        e(MUSIK, "ORGEL", "Kircheninstrument mit vielen Pfeifen"),
        e(MUSIK, "TROMPETE", "Blechblasinstrument mit drei Ventilen"),
        e(MUSIK, "SCHLAGER", "Eingängiges Lied, oft über die Liebe"),
        e(MUSIK, "OPERETTE", "Heiteres Bühnenwerk, z. B. 'Die Fledermaus'"),
        e(MUSIK, "KLAVIER", "Instrument mit schwarzen und weißen Tasten"),
        e(MUSIK, "CHOR", "Gruppe singender Menschen"),
        e(MUSIK, "SERENADE", "Ständchen unter dem Fenster"),
        e(MUSIK, "MELODIE", "Abfolge von Tönen, die man mitsummt"),
        e(MUSIK, "GEIGE", "Streichinstrument, wird unters Kinn geklemmt"),

        e(NATUR, "TULPE", "Frühlingsblume, Wahrzeichen der Niederlande"),
        e(NATUR, "ROSE", "Königin der Blumen, hat Dornen"),
        e(NATUR, "SONNENBLUME", "Gelbe Riesenblume, folgt der Sonne"),
        e(NATUR, "GIESSKANNE", "Damit gießt man die Beete"),
        e(NATUR, "IGEL", "Stacheliges Tier, hält Winterschlaf"),
        e(NATUR, "EICHHÖRNCHEN", "Flinker Baumkletterer, sammelt Nüsse"),
        e(NATUR, "SCHMETTERLING", "Bunter Falter, war einmal eine Raupe"),
        e(NATUR, "KOMPOST", "Hier verrotten Gartenabfälle zu Erde"),
        e(NATUR, "BIENE", "Fleißiges Insekt, sammelt Nektar"),
        e(NATUR, "LAVENDEL", "Violette Heilpflanze mit starkem Duft"),
        e(NATUR, "EICHE", "Baum, dessen Früchte Eicheln heißen"),
        e(NATUR, "STORCH", "Zugvogel mit rotem Schnabel"),
        e(NATUR, "MARIENKÄFER", "Roter Käfer mit sieben Punkten"),
        e(NATUR, "HARKE", "Gartengerät zum Zusammenrechen von Laub"),
        e(NATUR, "FLIEDER", "Strauch mit duftenden violetten Blüten im Mai"),

        e(KUECHE, "SAUERKRAUT", "Gesäuerter Weißkohl"),
        e(KUECHE, "KARTOFFEL", "Knolle für Püree, Pommes und Salzkartoffeln"),
        e(KUECHE, "NUDELN", "Spaghetti, Penne und Co."),
        e(KUECHE, "PFANNKUCHEN", "Dünn gebacken aus Eiern, Milch und Mehl"),
        e(KUECHE, "APFELSTRUDEL", "Österreichisches Gebäck mit Äpfeln und Rosinen"),
        e(KUECHE, "SUPPE", "Wird mit dem Löffel gegessen"),
        e(KUECHE, "SCHNITZEL", "Paniertes Fleisch, oft 'Wiener Art'"),
        e(KUECHE, "BACKOFEN", "Hier wird der Kuchen gebacken"),
        e(KUECHE, "MEHL", "Gemahlenes Getreide für Brot und Kuchen"),
        e(KUECHE, "ZIMT", "Weihnachtsgewürz aus Baumrinde"),
        e(KUECHE, "KAFFEE", "Beliebtes Heißgetränk am Nachmittag"),
        e(KUECHE, "GULASCH", "Ungarisches Fleischgericht mit Paprika"),
        e(KUECHE, "MARMELADE", "Eingekochte Früchte fürs Frühstücksbrot"),
        e(KUECHE, "KNÖDEL", "Runder Kloß aus Kartoffeln oder Semmeln"),
        e(KUECHE, "ZWIEBEL", "Beim Schneiden kommen einem die Tränen"),

        e(GEO, "BERLIN", "Hauptstadt Deutschlands"),
        e(GEO, "HAMBURG", "Hafenstadt an der Elbe"),
        e(GEO, "MÜNCHEN", "Hauptstadt Bayerns, bekannt fürs Oktoberfest"),
        e(GEO, "RHEIN", "Berühmter Fluss mit der Loreley"),
        e(GEO, "DONAU", "Zweitlängster Strom Europas, fließt nach Wien"),
        e(GEO, "ALPEN", "Hohes Gebirge im Süden Deutschlands"),
        e(GEO, "OSTSEE", "Meer im Norden, Rügen liegt darin"),
        e(GEO, "KÖLN", "Stadt mit berühmtem Dom am Rhein"),
        e(GEO, "DRESDEN", "Sachsens Hauptstadt mit der Frauenkirche"),
        e(GEO, "WIEN", "Hauptstadt Österreichs"),
        e(GEO, "BODENSEE", "Großer See an der Grenze zu Österreich und der Schweiz"),
        e(GEO, "ITALIEN", "Land in Form eines Stiefels"),
        e(GEO, "HARZ", "Mittelgebirge mit dem Brocken"),
        e(GEO, "ELBE", "Fluss, der durch Dresden und Hamburg fließt"),
        e(GEO, "BREMEN", "Stadt der Stadtmusikanten")
    )

    private val CATEGORIES = listOf(MUSIK, NATUR, KUECHE, GEO)

    private class Placement(val entry: Entry, val row: Int, val col: Int, val dir: Dir)

    private class Board {
        val grid = Array(SIZE) { CharArray(SIZE) { ' ' } }
        val used = Array(SIZE) { IntArray(SIZE) }
        val placed = mutableListOf<Placement>()

        private fun empty(r: Int, c: Int) = r !in 0 until SIZE || c !in 0 until SIZE || grid[r][c] == ' '

        fun canPlace(word: String, r: Int, c: Int, dir: Dir): Boolean {
            val dr = if (dir == Dir.DOWN) 1 else 0
            val dc = if (dir == Dir.ACROSS) 1 else 0
            val endR = r + dr * (word.length - 1)
            val endC = c + dc * (word.length - 1)
            if (r < 0 || c < 0 || endR >= SIZE || endC >= SIZE) return false
            if (!empty(r - dr, c - dc) || !empty(endR + dr, endC + dc)) return false
            val bit = if (dir == Dir.ACROSS) 1 else 2
            var crossings = 0
            for (i in word.indices) {
                val rr = r + dr * i
                val cc = c + dc * i
                val cur = grid[rr][cc]
                if (cur == ' ') {
                    // Nachbarn quer zur Richtung müssen frei sein
                    if (!empty(rr + dc, cc + dr) || !empty(rr - dc, cc - dr)) return false
                } else {
                    if (cur != word[i]) return false
                    if (used[rr][cc] and bit != 0) return false
                    crossings++
                }
            }
            return placed.isEmpty() || crossings > 0
        }

        fun place(entry: Entry, r: Int, c: Int, dir: Dir) {
            val dr = if (dir == Dir.DOWN) 1 else 0
            val dc = if (dir == Dir.ACROSS) 1 else 0
            val bit = if (dir == Dir.ACROSS) 1 else 2
            for (i in entry.answer.indices) {
                grid[r + dr * i][c + dc * i] = entry.answer[i]
                used[r + dr * i][c + dc * i] = used[r + dr * i][c + dc * i] or bit
            }
            placed.add(Placement(entry, r, c, dir))
        }
    }

    private fun tryBuild(): Board {
        val board = Board()
        val candidates = CATEGORIES
            .flatMap { cat -> POOL.filter { it.category == cat }.shuffled().take(6) }
            .sortedByDescending { it.answer.length }
        val first = candidates.first()
        board.place(first, SIZE / 2, (SIZE - first.answer.length) / 2, Dir.ACROSS)

        for (entry in candidates.drop(1)) {
            if (board.placed.size >= TARGET_WORDS) break
            val options = mutableListOf<Placement>()
            for (dir in Dir.values()) {
                for (r in 0 until SIZE) for (c in 0 until SIZE) {
                    if (board.canPlace(entry.answer, r, c, dir)) options.add(Placement(entry, r, c, dir))
                }
            }
            if (options.isNotEmpty()) {
                val o = options.random()
                board.place(o.entry, o.row, o.col, o.dir)
            }
        }
        return board
    }

    fun generate(): Puzzle {
        var best: Board? = null
        repeat(ATTEMPTS) {
            val b = tryBuild()
            val cur = best
            if (cur == null || b.placed.size > cur.placed.size) best = b
        }
        val board = best!!

        var minR = SIZE; var maxR = 0; var minC = SIZE; var maxC = 0
        for (r in 0 until SIZE) for (c in 0 until SIZE) {
            if (board.grid[r][c] != ' ') {
                minR = minOf(minR, r); maxR = maxOf(maxR, r)
                minC = minOf(minC, c); maxC = maxOf(maxC, c)
            }
        }
        val rows = maxR - minR + 1
        val cols = maxC - minC + 1
        val solution = Array(rows) { r -> CharArray(cols) { c -> board.grid[minR + r][minC + c] } }

        val sorted = board.placed.sortedWith(compareBy({ it.row }, { it.col }))
        val numbers = LinkedHashMap<Pair<Int, Int>, Int>()
        for (p in sorted) numbers.getOrPut(p.row to p.col) { numbers.size + 1 }

        val words = board.placed.map {
            PlacedWord(numbers[it.row to it.col]!!, it.entry, it.row - minR, it.col - minC, it.dir)
        }.sortedWith(compareBy({ it.number }, { it.dir }))

        return Puzzle(rows, cols, solution, words)
    }
}
